import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Flaire } from '../src/service.js';
import { parseAmount, toHalalas, fmt } from '../src/money.js';
import { normalizeMerchant, merchantMatches } from '../src/util.js';
import { compilePolicy, DEFAULT_POLICY, EXAMPLE_SCHEDULE } from '../src/policy.js';
import { evaluate, inSchedule } from '../src/engine.js';
import { createMcpHandler } from '../src/mcp.js';

const fresh = (fund = '2000') => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'flaire-test-'));
  const f = new Flaire(home);
  f.init();
  f.addAgent('bot', fund);
  return { f, home };
};

test('money is exact integer halalas', () => {
  assert.equal(parseAmount('0.10') + parseAmount('0.20'), 30);
  assert.equal(parseAmount(12.5), 1250);
  assert.equal(toHalalas(2000, 'USD'), 7500);
  assert.throws(() => parseAmount('abc'));
  assert.throws(() => parseAmount('-5'));
  assert.throws(() => parseAmount('0'));
  assert.throws(() => parseAmount('1.234'));
  assert.equal(fmt(123456, 'en'), 'SAR 1,234.56');
  assert.equal(fmt(123456, 'ar'), '١٬٢٣٤٫٥٦ ر.س');
});

test('merchant matching cannot be spoofed', () => {
  assert.equal(normalizeMerchant('https://www.Jarir.com/cart?x=1'), 'jarir.com');
  assert.ok(merchantMatches('jarir.com', 'jarir.com'));
  assert.ok(merchantMatches('jarir.com', 'shop.jarir.com'));
  assert.ok(!merchantMatches('jarir.com', 'evil-jarir.com'));
  assert.ok(!merchantMatches('jarir.com', 'jarir.com.evil.xyz'));
  assert.ok(merchantMatches('*.gov.sa', 'moi.gov.sa'));
  assert.throws(() => normalizeMerchant('jаrir.com')); // Cyrillic "а"
});

test('allow, then duplicate is denied', () => {
  const { f } = fresh();
  const a = f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 100 });
  assert.equal(a.verdict, 'allow');
  assert.ok(a.receipt.startsWith('rcpt.'));
  const b = f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 100 });
  assert.equal(b.verdict, 'deny');
  assert.equal(b.reasons[0].code, 'DUPLICATE_REQUEST');
});

test('idempotency key replays instead of double spending', () => {
  const { f } = fresh();
  const a = f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 100, idempotencyKey: 'k1' });
  const b = f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 100, idempotencyKey: 'k1' });
  assert.equal(b.id, a.id);
  assert.equal(b.replay, true);
  assert.equal(f.balance('bot').balanceHalalas, 190000);
  assert.throws(() => f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 101, idempotencyKey: 'k1' }), /already used/);
});

test('big request is denied, unknown vendor goes to review, over threshold goes to review', () => {
  const { f } = fresh();
  assert.equal(f.authorize({ agent: 'bot', merchant: 'x.xyz', amount: 4800 }).reasons[0].code, 'OVER_TX_CAP');
  const u = f.authorize({ agent: 'bot', merchant: 'unknown.shop', amount: 50 });
  assert.equal(u.verdict, 'review');
  assert.equal(u.reasons[0].code, 'NO_RULE_MATCH');
  const o = f.authorize({ agent: 'bot', merchant: 'noon.com', amount: 280 });
  assert.equal(o.verdict, 'review');
  assert.equal(o.reasons[0].code, 'OVER_REVIEW_THRESHOLD');
  assert.equal(f.balance('bot').balanceHalalas, 200000, 'review does not spend');
});

test('USD converts at 3.75 and is checked in SAR', () => {
  const { f } = fresh();
  const d = f.authorize({ agent: 'bot', merchant: 'openai.com', amount: 20, currency: 'USD', action: 'api_call' });
  assert.equal(d.verdict, 'allow');
  assert.equal(d.amount.sar, '75.00');
});

test('rule daily limit and global daily limit', () => {
  const { f } = fresh('5000');
  assert.equal(f.authorize({ agent: 'bot', merchant: 'careem.com', amount: 140 }).verdict, 'allow');
  assert.equal(f.authorize({ agent: 'bot', merchant: 'careem.com', amount: 150 }).verdict, 'allow');
  assert.equal(f.authorize({ agent: 'bot', merchant: 'careem.com', amount: 100 }).reasons[0].code, 'OVER_RULE_DAILY');
  // 290 spent so far. Walk toward the 1000 daily cap with amounts under the 250 review threshold.
  assert.equal(f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 240 }).verdict, 'allow'); // 530
  assert.equal(f.authorize({ agent: 'bot', merchant: 'noon.com', amount: 240 }).verdict, 'allow'); // 770
  assert.equal(f.authorize({ agent: 'bot', merchant: 'stc.com.sa', amount: 230 }).verdict, 'allow'); // exactly 1000
  assert.equal(f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 20 }).reasons[0].code, 'OVER_DAILY');
});

test('insufficient balance is denied', () => {
  const { f } = fresh('100');
  assert.equal(f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 150 }).reasons[0].code, 'INSUFFICIENT_FUNDS');
});

test('blocked category and unknown agent', () => {
  const { f } = fresh();
  assert.equal(f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 10, category: 'gambling' }).reasons[0].code, 'BLOCKED_CATEGORY');
  assert.equal(f.authorize({ agent: 'ghost', merchant: 'jarir.com', amount: 10 }).reasons[0].code, 'UNKNOWN_AGENT');
});

test('government payments always need the owner', () => {
  const { f } = fresh();
  const d = f.authorize({ agent: 'bot', merchant: 'moi.gov.sa', amount: 50, action: 'bill_payment' });
  assert.equal(d.verdict, 'review');
  assert.equal(d.reasons[0].code, 'RULE_REVIEW');
});

test('owner approval spends once and issues a receipt; reject spends nothing', () => {
  const { f } = fresh();
  const r = f.authorize({ agent: 'bot', merchant: 'noon.com', amount: 280 });
  const a = f.resolve(r.id, 'approve');
  assert.equal(a.status, 'approved');
  assert.ok(a.receipt);
  assert.equal(f.balance('bot').balanceHalalas, 172000);
  assert.throws(() => f.resolve(r.id, 'approve'), /already approved/);
  const r2 = f.authorize({ agent: 'bot', merchant: 'unknown.shop', amount: 50 });
  assert.equal(f.resolve(r2.id, 'reject').status, 'rejected');
  assert.equal(f.balance('bot').balanceHalalas, 172000);
});

test('kill switch denies new requests, blocks stale approvals and kills old receipts', () => {
  const { f } = fresh();
  const ok = f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 100 });
  assert.equal(f.verifyReceipt(ok.receipt).valid, true);
  const held = f.authorize({ agent: 'bot', merchant: 'unknown.shop', amount: 50 });
  f.pause('bot');
  assert.equal(f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 33 }).reasons[0].code, 'KILL_SWITCH_AGENT');
  assert.equal(f.verifyReceipt(ok.receipt).reason, 'REVOKED_BY_KILL_SWITCH');
  assert.equal(f.resolve(held.id, 'approve').status, 'denied');
  f.resume('bot');
  f.pause('all');
  assert.equal(f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 34 }).reasons[0].code, 'KILL_SWITCH_ALL');
});

test('receipts: tampered, expired, single use', () => {
  const { f } = fresh();
  const ok = f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 100 });
  const parts = ok.receipt.split('.');
  const forged = JSON.parse(Buffer.from(parts[1], 'base64url'));
  forged.amt = 1;
  const bad = `rcpt.${Buffer.from(JSON.stringify(forged)).toString('base64url')}.${parts[2]}`;
  assert.equal(f.verifyReceipt(bad).reason, 'BAD_SIGNATURE');
  assert.equal(f.verifyReceipt(ok.receipt, { consume: true }).valid, true);
  assert.equal(f.verifyReceipt(ok.receipt).reason, 'ALREADY_USED');
  // expiry: decision made 10 minutes ago
  const old = f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 101 }, { now: new Date(Date.now() - 600000) });
  assert.equal(f.verifyReceipt(old.receipt).reason, 'EXPIRED');
});

test('log is tamper evident', () => {
  const { f, home } = fresh();
  f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 120 });
  f.authorize({ agent: 'bot', merchant: 'noon.com', amount: 130 });
  assert.equal(f.verifyLedger().ok, true);
  const file = path.join(home, 'decisions.jsonl');
  fs.writeFileSync(file, fs.readFileSync(file, 'utf8').replace('"amountHalalas":12000', '"amountHalalas":100'));
  const v = f.verifyLedger();
  assert.equal(v.ok, false);
  assert.equal(v.brokenAt, 2);
});

test('policy validation reports problems', () => {
  assert.throws(() => compilePolicy({ rules: [{ id: 'a', verdict: 'maybe' }] }), /verdict/);
  assert.throws(() => compilePolicy({ limits: { daily: 'lots' } }), /limits.daily/);
  assert.ok(compilePolicy(DEFAULT_POLICY));
});

test('working-hours schedule uses Riyadh time, Sunday to Thursday', () => {
  const p = compilePolicy({ ...DEFAULT_POLICY, schedule: EXAMPLE_SCHEDULE });
  assert.equal(inSchedule(p.schedule, new Date('2026-10-18T09:00:00+03:00')), true); // Sunday 09:00
  assert.equal(inSchedule(p.schedule, new Date('2026-10-16T09:00:00+03:00')), false); // Friday
  assert.equal(inSchedule(p.schedule, new Date('2026-10-18T20:00:00+03:00')), false); // Sunday night
  const st = { agents: { bot: { balance: 100000, paused: false } }, globalPaused: false, settled: [], recent: [] };
  const req = { agent: 'bot', merchant: 'jarir.com', action: 'purchase', category: null, amountHalalas: 5000 };
  assert.equal(evaluate(p, st, req, { now: new Date('2026-10-16T09:00:00+03:00') }).reasons[0].code, 'OUTSIDE_HOURS');
  assert.equal(evaluate(p, st, req, { now: new Date('2026-10-18T09:00:00+03:00') }).verdict, 'allow');
});

test('policy edits apply immediately', () => {
  const { f } = fresh();
  const raw = f.policy().raw;
  raw.rules.find((r) => r.id === 'jarir').verdict = 'deny';
  fs.writeFileSync(f.policyFile, JSON.stringify(raw));
  assert.equal(f.authorize({ agent: 'bot', merchant: 'jarir.com', amount: 10 }).reasons[0].code, 'RULE_DENY');
});

test('MCP: tools list, authorize, and no owner powers exposed', async () => {
  const { f } = fresh();
  const h = createMcpHandler(f);
  assert.equal(await h({ jsonrpc: '2.0', method: 'notifications/initialized' }), null);
  assert.equal((await h({ jsonrpc: '2.0', id: 1, method: 'initialize', params: {} })).result.serverInfo.name, 'flaire');
  const names = (await h({ jsonrpc: '2.0', id: 2, method: 'tools/list' })).result.tools.map((t) => t.name);
  assert.deepEqual(names, ['authorize_action', 'get_decision', 'get_pending_approvals', 'get_balance']);
  const call = await h({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'authorize_action', arguments: { agent: 'bot', merchant: 'jarir.com', amount: 75, idempotency_key: 'm1' } } });
  assert.equal(JSON.parse(call.result.content[0].text).verdict, 'allow');
  const bad = await h({ jsonrpc: '2.0', id: 4, method: 'tools/call', params: { name: 'authorize_action', arguments: { agent: 'bot', merchant: 'jarir.com', amount: 'abc' } } });
  assert.equal(bad.result.isError, true);
});
