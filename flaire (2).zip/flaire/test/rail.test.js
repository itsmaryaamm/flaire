import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { Flaire } from '../src/service.js';
import { LithicRail, authorizeAndPay, resolveAndPay, addAgentOnRail, fundOnRail, pauseOnRail, halalasToUsdCents } from '../src/rail.js';
import { createMcpHandler } from '../src/mcp.js';

// A tiny fake of the Lithic sandbox so tests never touch the network.
function mockLithic() {
  const cards = new Map();
  const calls = [];
  const flags = { limitNext: 0 };
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      const body = raw ? JSON.parse(raw) : {};
      const send = (code, o) => {
        res.writeHead(code, { 'content-type': 'application/json' });
        res.end(JSON.stringify(o));
      };
      calls.push({ method: req.method, url: req.url, body, auth: req.headers.authorization });
      if (flags.limitNext > 0) {
        flags.limitNext--;
        res.writeHead(429, { 'content-type': 'application/json', 'retry-after': '0' });
        return res.end(JSON.stringify({ message: 'Rate limit exceeded.' }));
      }
      if (req.headers.authorization !== 'test-key') return send(401, { message: 'bad key' });
      if (req.method === 'POST' && req.url === '/v1/cards') {
        const token = 'card-' + (cards.size + 1);
        const c = { token, pan: '4111111111111' + String(1000 + cards.size), last_four: '1000', spend_limit: body.spend_limit, spent: 0, state: 'OPEN' };
        cards.set(token, c);
        return send(200, c);
      }
      const m = /^\/v1\/cards\/(.+)$/.exec(req.url);
      if (req.method === 'PATCH' && m) {
        Object.assign(cards.get(m[1]), body);
        return send(200, cards.get(m[1]));
      }
      if (req.method === 'POST' && req.url === '/v1/simulate/authorize') {
        const c = [...cards.values()].find((x) => x.pan === body.pan);
        if (!c) return send(422, { message: 'unknown card' });
        if (c.state !== 'OPEN') return send(422, { message: 'Card is paused' });
        if (c.spent + body.amount > c.spend_limit) return send(422, { message: 'Transaction exceeds user-set transaction limit.' });
        c.spent += body.amount;
        return send(200, { token: 'auth-' + calls.length, debugging_request_id: 'x' });
      }
      if (req.method === 'POST' && req.url === '/v1/simulate/clearing') return send(200, { debugging_request_id: 'x' });
      send(404, { message: 'nope' });
    });
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({ server, cards, calls, flags, url: `http://127.0.0.1:${server.address().port}/v1` })));
}

async function setup() {
  const mock = await mockLithic();
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'flaire-rail-'));
  const f = new Flaire(home);
  f.init();
  const rail = new LithicRail(f, { apiKey: 'test-key', baseUrl: mock.url, retryScale: 0 });
  return { mock, f, rail };
}

test('SAR converts to US cents at the 3.75 peg', () => {
  assert.equal(halalasToUsdCents(7500), 2000);
  assert.equal(halalasToUsdCents(12000), 3200);
});

test('refuses anything that is not the Lithic sandbox', () => {
  const f = new Flaire(fs.mkdtempSync(path.join(os.tmpdir(), 'flaire-rail-')));
  assert.throws(() => new LithicRail(f, { apiKey: 'k', baseUrl: 'https://api.lithic.com/v1' }), /SANDBOX/);
  assert.throws(() => new LithicRail(f, { apiKey: 'k', baseUrl: 'https://sandbox.lithic.com.evil.com/v1' }), /SANDBOX/);
  assert.throws(() => new LithicRail(f, { baseUrl: 'https://sandbox.lithic.com/v1' }), /LITHIC_API_KEY/);
});

test('allowed request is charged on the Lithic card once; denied request never reaches Lithic', async () => {
  const { mock, f, rail } = await setup();
  await addAgentOnRail(f, rail, 'bot', '2000');
  assert.equal([...mock.cards.values()][0].spend_limit, 53333); // SAR 2000 -> USD cents
  const ok = await authorizeAndPay(f, rail, { agent: 'bot', merchant: 'jarir.com', amount: 120 });
  assert.equal(ok.status, 'approved');
  assert.equal(ok.rail.ok, true);
  assert.equal(ok.rail.usdCents, 3200);
  const charges = mock.calls.filter((c) => c.url === '/v1/simulate/authorize');
  assert.equal(charges.length, 1);
  assert.equal(charges[0].body.amount, 3200);
  assert.equal(charges[0].body.descriptor, 'JARIR.COM');
  const denied = await authorizeAndPay(f, rail, { agent: 'bot', merchant: 'evil.xyz', amount: 4800 });
  assert.equal(denied.verdict, 'deny');
  assert.equal(denied.rail, undefined);
  assert.equal(mock.calls.filter((c) => c.url === '/v1/simulate/authorize').length, 1, 'no second charge');
  mock.server.close();
});

test('held request is charged only after the owner approves; receipt cannot be replayed', async () => {
  const { mock, f, rail } = await setup();
  await addAgentOnRail(f, rail, 'bot', '2000');
  const held = await authorizeAndPay(f, rail, { agent: 'bot', merchant: 'noon.com', amount: 280 });
  assert.equal(held.status, 'pending');
  assert.equal(mock.calls.filter((c) => c.url === '/v1/simulate/authorize').length, 0);
  const done = await resolveAndPay(f, rail, held.id, 'approve');
  assert.equal(done.rail.ok, true);
  const replay = await rail.pay(held.id, done.receipt);
  assert.equal(replay.ok, false);
  assert.match(replay.error, /ALREADY_USED/);
  assert.equal(mock.calls.filter((c) => c.url === '/v1/simulate/authorize').length, 1);
  mock.server.close();
});

test('if Lithic declines, the budget is given back and the decision shows rail_failed', async () => {
  const { mock, f, rail } = await setup();
  await addAgentOnRail(f, rail, 'bot', '2000');
  [...mock.cards.values()][0].spend_limit = 100; // Lithic side is nearly empty (drift)
  const d = await authorizeAndPay(f, rail, { agent: 'bot', merchant: 'jarir.com', amount: 120 });
  assert.equal(d.status, 'rail_failed');
  assert.equal(d.rail.ok, false);
  assert.match(d.rail.error, /exceeds/);
  assert.equal(f.balance('bot').balanceHalalas, 200000, 'budget returned');
  mock.server.close();
});

test('kill switch pauses the card at Lithic, and Lithic then refuses', async () => {
  const { mock, f, rail } = await setup();
  await addAgentOnRail(f, rail, 'bot', '2000');
  await pauseOnRail(f, rail, 'pause', 'bot');
  assert.equal([...mock.cards.values()][0].state, 'PAUSED');
  await pauseOnRail(f, rail, 'resume', 'bot');
  assert.equal([...mock.cards.values()][0].state, 'OPEN');
  await pauseOnRail(f, rail, 'pause', 'all');
  assert.equal([...mock.cards.values()][0].state, 'PAUSED');
  mock.server.close();
});

test('funding raises the Lithic card limit', async () => {
  const { mock, f, rail } = await setup();
  await addAgentOnRail(f, rail, 'bot', '100');
  await fundOnRail(f, rail, 'bot', '375'); // SAR 475 total
  assert.equal([...mock.cards.values()][0].spend_limit, halalasToUsdCents(47500));
  mock.server.close();
});

test('bad API key gives a clear failure and returns the budget', async () => {
  const { mock, f } = await setup();
  const bad = new LithicRail(f, { apiKey: 'wrong', baseUrl: mock.url });
  f.addAgent('bot', '2000');
  const d = await authorizeAndPay(f, bad, { agent: 'bot', merchant: 'jarir.com', amount: 120 });
  assert.equal(d.status, 'rail_failed');
  assert.match(d.rail.error, /bad key/);
  mock.server.close();
});

test('MCP authorize charges the rail too', async () => {
  const { mock, f, rail } = await setup();
  await addAgentOnRail(f, rail, 'bot', '2000');
  const h = createMcpHandler(f, rail);
  const r = await h({ jsonrpc: '2.0', id: 1, method: 'tools/call', params: { name: 'authorize_action', arguments: { agent: 'bot', merchant: 'jarir.com', amount: 50 } } });
  const out = JSON.parse(r.result.content[0].text);
  assert.equal(out.rail.ok, true);
  mock.server.close();
});

test('rate limit from Lithic is waited out and retried instead of failing', async () => {
  const { mock, f, rail } = await setup();
  await addAgentOnRail(f, rail, 'bot', '2000');
  mock.flags.limitNext = 2; // the next two requests get "slow down"
  const d = await authorizeAndPay(f, rail, { agent: 'bot', merchant: 'jarir.com', amount: 120 });
  assert.equal(d.rail.ok, true);
  mock.flags.limitNext = 99; // permanently limited: gives up with a clear message and returns the budget
  const d2 = await authorizeAndPay(f, rail, { agent: 'bot', merchant: 'noon.com', amount: 130 });
  assert.equal(d2.status, 'rail_failed');
  assert.match(d2.rail.error, /Rate limit/);
  mock.server.close();
});
