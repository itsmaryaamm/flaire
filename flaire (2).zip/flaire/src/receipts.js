import { createHmac, timingSafeEqual } from 'node:crypto';

// A receipt proves "Flaire approved exactly this". Whatever executes the payment should check it.
// It is bound to one decision, agent, merchant and amount, and it expires after 5 minutes.
export const RECEIPT_TTL_SECONDS = 300;

const b64 = (b) => Buffer.from(b).toString('base64url');

export function signReceipt(secret, d, baseTimeMs) {
  const payload = b64(
    JSON.stringify({
      d: d.id,
      a: d.agent,
      act: d.action,
      m: d.merchant,
      amt: d.amountHalalas,
      cur: 'SAR',
      exp: Math.floor(baseTimeMs / 1000) + RECEIPT_TTL_SECONDS
    })
  );
  const sig = createHmac('sha256', secret).update(payload).digest('base64url');
  return `rcpt.${payload}.${sig}`;
}

export function openReceipt(secret, token, nowMs = Date.now()) {
  const parts = String(token ?? '').split('.');
  if (parts.length !== 3 || parts[0] !== 'rcpt') return { valid: false, reason: 'MALFORMED' };
  const expected = createHmac('sha256', secret).update(parts[1]).digest();
  let given;
  try {
    given = Buffer.from(parts[2], 'base64url');
  } catch {
    return { valid: false, reason: 'MALFORMED' };
  }
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return { valid: false, reason: 'BAD_SIGNATURE' };
  let claims;
  try {
    claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
  } catch {
    return { valid: false, reason: 'MALFORMED' };
  }
  if (Math.floor(nowMs / 1000) > claims.exp) return { valid: false, reason: 'EXPIRED', claims };
  return { valid: true, claims };
}
