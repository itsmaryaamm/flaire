import { fmt } from './money.js';

const useColor = process.stdout.isTTY && !process.env.NO_COLOR;
const c = (code) => (s) => (useColor ? `\x1b[${code}m${s}\x1b[0m` : s);
export const green = c('32');
export const red = c('31');
export const amber = c('33');
export const dim = c('2');
export const bold = c('1');

const TAG = { allow: green('[ALLOW]'), deny: red('[DENY] '), review: amber('[REVIEW]') };
const TAG_AR = { allow: green('[موافقة]'), deny: red('[رفض]'), review: amber('[مراجعة]') };

export function printDecision(d, lang = 'en', log = console.log, { shortReceipt = false } = {}) {
  const tag = (lang === 'ar' ? TAG_AR : TAG)[d.verdict];
  log(`${tag} ${bold(d.id)}  ${d.agent} -> ${d.merchant}  ${fmt(d.amount.halalas, lang)}` + (d.amount.original?.currency === 'USD' ? dim(`  (USD ${d.amount.original.amount})`) : ''));
  for (const r of d.reasons) log(dim(`        ${r.code}: ${r.message[lang]}`));
  if (d.resolution) {
    log(`        ${bold(d.resolution.outcome.toUpperCase())} by ${d.resolution.by}`);
    for (const r of d.resolution.reasons) log(dim(`        ${r.code}: ${r.message[lang]}`));
  }
  if (d.rail) log(d.rail.ok ? green(`        Lithic sandbox: charged USD ${(d.rail.usdCents / 100).toFixed(2)}  (auth ${String(d.rail.authToken).slice(0, 8)}...)`) : red(`        Lithic sandbox FAILED, budget returned: ${d.rail.error}`));
  if (d.receipt) log(dim(`        receipt: ${shortReceipt ? d.receipt.slice(0, 24) + '...' : d.receipt}`));
  if (d.status === 'pending') log(amber(`        waiting for owner: flaire approve ${d.id}   or   flaire reject ${d.id}`));
}
