import { createHash, randomBytes } from 'node:crypto';

export class FlaireError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

// Stable JSON: sorted keys, so a hash never depends on key order.
export function canonical(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
  return (
    '{' +
    Object.keys(v)
      .sort()
      .filter((k) => v[k] !== undefined)
      .map((k) => JSON.stringify(k) + ':' + canonical(v[k]))
      .join(',') +
    '}'
  );
}

export const sha256 = (s) => createHash('sha256').update(s).digest('hex');
export const newId = (prefix) => prefix + '_' + randomBytes(5).toString('hex');

// "https://www.Jarir.com/cart?x=1" -> "jarir.com". ASCII only on purpose:
// look-alike (homoglyph) domains are rejected instead of silently matched.
export function normalizeMerchant(input) {
  let s = String(input ?? '').trim().toLowerCase();
  s = s.replace(/^[a-z]+:\/\//, '').split(/[/?#]/)[0].replace(/:\d+$/, '').replace(/^www\./, '');
  if (!/^[a-z0-9][a-z0-9._-]{0,98}$/.test(s)) {
    throw new FlaireError('invalid_request', `Invalid merchant "${input}". Use an ASCII domain or name, e.g. jarir.com`);
  }
  return s;
}

// exact match, subdomain match, or "*.sa" style suffix. "evil-jarir.com" never matches "jarir.com".
export function merchantMatches(pattern, merchant) {
  const p = pattern.toLowerCase();
  if (p === '*') return true;
  if (p.startsWith('*.')) return merchant.endsWith(p.slice(1));
  return merchant === p || merchant.endsWith('.' + p);
}
