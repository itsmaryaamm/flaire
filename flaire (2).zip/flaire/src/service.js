import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { FlaireError, newId, normalizeMerchant } from './util.js';
import { parseAmount, toHalalas, plain } from './money.js';
import { DEFAULT_POLICY, loadPolicyFile } from './policy.js';
import { evaluate } from './engine.js';
import { describe } from './reasons.js';
import { Store, buildState, verifyChain } from './store.js';
import { signReceipt, openReceipt } from './receipts.js';

const NAME = /^[A-Za-z0-9_.-]{1,40}$/;

export function defaultHome() {
  return process.env.FLAIRE_HOME || path.join(os.homedir(), '.flaire');
}

export function normalizeRequest(i) {
  const bad = (m) => {
    throw new FlaireError('invalid_request', m);
  };
  if (!i || typeof i !== 'object') bad('Request must be an object.');
  if (typeof i.agent !== 'string' || !NAME.test(i.agent)) bad('agent: required, letters, numbers, dot, dash, underscore.');
  const currency = String(i.currency ?? 'SAR').toUpperCase();
  const original = parseAmount(i.amount);
  const action = String(i.action ?? 'purchase').toLowerCase();
  if (!/^[a-z_]{1,30}$/.test(action)) bad('action: lowercase letters and underscores only.');
  let category = null;
  if (i.category != null && i.category !== '') {
    category = String(i.category).toLowerCase();
    if (!/^[a-z_ -]{1,30}$/.test(category)) bad('category: letters only.');
  }
  const purpose = i.purpose == null ? null : String(i.purpose).slice(0, 300);
  const key = i.idempotencyKey == null ? null : String(i.idempotencyKey);
  if (key && key.length > 80) bad('idempotencyKey: max 80 characters.');
  return {
    agent: i.agent,
    merchant: normalizeMerchant(i.merchant),
    action,
    category,
    purpose,
    idempotencyKey: key,
    amountHalalas: toHalalas(original, currency),
    original: { minor: original, currency }
  };
}

export class Flaire {
  constructor(home = defaultHome()) {
    this.home = home;
    this.store = new Store(home);
    this.policyFile = path.join(home, 'policy.json');
    this.secretFile = path.join(home, 'secret.key');
  }

  init() {
    this.store.ensure();
    const created = [];
    if (!fs.existsSync(this.policyFile)) {
      fs.writeFileSync(this.policyFile, JSON.stringify(DEFAULT_POLICY, null, 2) + '\n');
      created.push(this.policyFile);
    }
    if (!fs.existsSync(this.secretFile) && !process.env.FLAIRE_RECEIPT_SECRET) {
      fs.writeFileSync(this.secretFile, randomBytes(32).toString('hex'), { mode: 0o600 });
      created.push(this.secretFile);
    }
    return { home: this.home, created };
  }

  policy() {
    if (!fs.existsSync(this.policyFile)) this.init();
    return loadPolicyFile(this.policyFile);
  }

  secret() {
    if (process.env.FLAIRE_RECEIPT_SECRET) return process.env.FLAIRE_RECEIPT_SECRET;
    if (!fs.existsSync(this.secretFile)) this.init();
    return fs.readFileSync(this.secretFile, 'utf8').trim();
  }

  // ---------- owner setup ----------
  addAgent(name, fund = '0') {
    if (!NAME.test(name ?? '')) throw new FlaireError('invalid_request', 'Agent name: letters, numbers, dot, dash, underscore.');
    const fundHalalas = parseAmount(fund, { allowZero: true });
    this.init();
    return this.store.withLock(() => {
      const recs = this.store.records();
      if (buildState(recs).agents[name]) throw new FlaireError('conflict', `Agent "${name}" already exists.`, 409);
      this.store.append({ type: 'agent', ts: new Date().toISOString(), name, fundHalalas }, recs);
      return { name, balance: plain(fundHalalas) };
    });
  }

  fund(agent, amount) {
    const amountHalalas = parseAmount(amount);
    return this.store.withLock(() => {
      const recs = this.store.records();
      const st = buildState(recs);
      if (!st.agents[agent]) throw new FlaireError('not_found', `Unknown agent "${agent}".`, 404);
      this.store.append({ type: 'fund', ts: new Date().toISOString(), agent, amountHalalas }, recs);
      return { agent, balance: plain(st.agents[agent].balance + amountHalalas) };
    });
  }

  pause(scope = 'all', by = 'owner') {
    return this.#control('pause', scope, by);
  }
  resume(scope = 'all', by = 'owner') {
    return this.#control('resume', scope, by);
  }
  #control(action, scope, by) {
    return this.store.withLock(() => {
      const recs = this.store.records();
      const st = buildState(recs);
      if (scope !== 'all' && !st.agents[scope]) throw new FlaireError('not_found', `Unknown agent "${scope}".`, 404);
      this.store.append({ type: 'control', ts: new Date().toISOString(), action, scope, by }, recs);
      return { action, scope };
    });
  }

  // ---------- the main call agents make ----------
  authorize(input, { now = new Date() } = {}) {
    const req = normalizeRequest(input);
    const { compiled, hash } = this.policy();
    return this.store.withLock(() => {
      const recs = this.store.records();
      const st = buildState(recs);

      if (req.idempotencyKey) {
        for (const d of st.decisions.values()) {
          if (d.agent === req.agent && d.idempotencyKey === req.idempotencyKey) {
            if (d.merchant !== req.merchant || d.amountHalalas !== req.amountHalalas) {
              throw new FlaireError('idempotency_conflict', 'That idempotency key was already used for a different request.', 409);
            }
            return this.#present(d, true);
          }
        }
      }

      const ev = evaluate(compiled, st, { ...req }, { now });
      const rec = this.store.append(
        {
          type: 'decision',
          id: newId('dec'),
          ts: now.toISOString(),
          agent: req.agent,
          action: req.action,
          merchant: req.merchant,
          category: req.category,
          purpose: req.purpose,
          idempotencyKey: req.idempotencyKey,
          amountHalalas: req.amountHalalas,
          original: req.original,
          verdict: ev.verdict,
          reasons: ev.reasons,
          trace: ev.trace,
          policy: hash
        },
        recs
      );
      return this.#present(buildState(recs).decisions.get(rec.id));
    });
  }

  // ---------- owner approves or rejects a held request ----------
  resolve(id, choice, by = 'owner', { now = new Date() } = {}) {
    if (!['approve', 'reject'].includes(choice)) throw new FlaireError('invalid_request', 'choice must be approve or reject');
    const { compiled } = this.policy();
    return this.store.withLock(() => {
      const recs = this.store.records();
      const st = buildState(recs);
      const d = st.decisions.get(id);
      if (!d) throw new FlaireError('not_found', `No decision ${id}.`, 404);
      if (d.status !== 'pending') throw new FlaireError('conflict', `Decision ${id} is already ${d.status}.`, 409);
      let outcome;
      let reasons;
      if (choice === 'reject') {
        outcome = 'rejected';
        reasons = [{ code: 'REJECTED_BY_OWNER' }];
      } else if (now.getTime() - d.at > compiled.pendingTtlMs) {
        outcome = 'expired';
        reasons = [{ code: 'PENDING_EXPIRED' }];
      } else {
        // Re-check hard limits at approval time. A pause or a spent budget since the request still blocks it.
        const ev = evaluate(compiled, st, d, { now, approving: true });
        outcome = ev.verdict === 'deny' ? 'denied' : 'approved';
        reasons = ev.verdict === 'deny' ? ev.reasons : [{ code: 'APPROVED_BY_OWNER' }];
      }
      this.store.append({ type: 'resolution', ts: now.toISOString(), decisionId: id, outcome, by, reasons }, recs);
      return this.#present(buildState(recs).decisions.get(id));
    });
  }

  recordRail(decisionId, data) {
    return this.store.withLock(() => {
      const recs = this.store.records();
      if (!buildState(recs).decisions.has(decisionId)) throw new FlaireError('not_found', `No decision ${decisionId}.`, 404);
      return this.store.append({ type: 'rail', ts: new Date().toISOString(), decisionId, ...data }, recs);
    });
  }

  // everything ever funded to this agent, in halalas (current balance plus everything spent)
  totalFunded(agent) {
    const st = buildState(this.store.records());
    if (!st.agents[agent]) throw new FlaireError('not_found', `Unknown agent "${agent}".`, 404);
    return st.agents[agent].balance + st.settled.filter((x) => x.agent === agent).reduce((t, x) => t + x.amount, 0);
  }

  // ---------- reading ----------
  getDecision(id) {
    const d = buildState(this.store.records()).decisions.get(id);
    if (!d) throw new FlaireError('not_found', `No decision ${id}.`, 404);
    return this.#present(d);
  }

  pending(agent) {
    return [...buildState(this.store.records()).decisions.values()]
      .filter((d) => d.status === 'pending' && (!agent || d.agent === agent))
      .map((d) => this.#present(d));
  }

  history({ sinceMs = 0, limit = 50 } = {}) {
    const list = [...buildState(this.store.records()).decisions.values()].filter((d) => d.at >= sinceMs);
    return list.slice(-limit).reverse().map((d) => this.#present(d));
  }

  balance(agent) {
    const a = buildState(this.store.records()).agents[agent];
    if (!a) throw new FlaireError('not_found', `Unknown agent "${agent}".`, 404);
    return { agent, balance: plain(a.balance), balanceHalalas: a.balance, currency: 'SAR', paused: a.paused };
  }

  status() {
    const recs = this.store.records();
    const st = buildState(recs);
    const now = Date.now();
    const sum = (agent, ms) => st.settled.filter((s) => s.agent === agent && s.at > now - ms).reduce((t, s) => t + s.amount, 0);
    return {
      home: this.home,
      globalPaused: st.globalPaused,
      agents: Object.entries(st.agents).map(([name, a]) => ({
        name,
        balance: plain(a.balance),
        paused: a.paused,
        spent24h: plain(sum(name, 24 * 3600 * 1000)),
        spent30d: plain(sum(name, 30 * 24 * 3600 * 1000))
      })),
      pending: [...st.decisions.values()].filter((d) => d.status === 'pending').length,
      chain: verifyChain(recs)
    };
  }

  verifyLedger() {
    return verifyChain(this.store.records());
  }

  // ---------- receipts ----------
  verifyReceipt(token, { consume = false } = {}) {
    const r = openReceipt(this.secret(), token);
    if (!r.valid) return r;
    return this.store.withLock(() => {
      const recs = this.store.records();
      const st = buildState(recs);
      const d = st.decisions.get(r.claims.d);
      const fail = (reason) => ({ valid: false, reason, claims: r.claims });
      if (!d || d.status !== 'approved') return fail('NOT_APPROVED');
      if (st.globalPaused || st.agents[d.agent]?.paused) return fail('REVOKED_BY_KILL_SWITCH');
      if (st.usedReceipts.has(d.id)) return fail('ALREADY_USED');
      if (consume) this.store.append({ type: 'receipt_use', ts: new Date().toISOString(), decisionId: d.id }, recs);
      return { valid: true, claims: r.claims };
    });
  }

  // ---------- presentation ----------
  #present(d, replay = false) {
    const out = {
      id: d.id,
      ts: d.ts,
      agent: d.agent,
      action: d.action,
      merchant: d.merchant,
      category: d.category,
      purpose: d.purpose,
      amount: { sar: plain(d.amountHalalas), halalas: d.amountHalalas, original: d.original && { amount: plain(d.original.minor), currency: d.original.currency } },
      verdict: d.verdict,
      status: d.status,
      reasons: d.reasons.map(describe),
      trace: d.trace,
      policy: d.policy
    };
    if (replay) out.replay = true;
    if (d.resolution) out.resolution = { outcome: d.resolution.outcome, by: d.resolution.by, ts: d.resolution.ts, reasons: d.resolution.reasons.map(describe) };
    if (d.rail) out.rail = { rail: d.rail.rail, ok: d.rail.ok, authToken: d.rail.authToken, usdCents: d.rail.usdCents, error: d.rail.error, ts: d.rail.ts };
    if (d.status === 'approved') {
      out.receipt = signReceipt(this.secret(), d, d.resolvedAt ?? d.at);
    }
    return out;
  }
}
