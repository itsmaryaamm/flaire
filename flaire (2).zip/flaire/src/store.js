import fs from 'node:fs';
import path from 'node:path';
import { canonical, sha256, FlaireError } from './util.js';

/**
 * Everything Flaire knows is one append-only file (decisions.jsonl).
 * Each record stores the hash of the one before it, so editing history breaks the chain.
 * Balances, pauses and spend totals are all rebuilt from this log, never stored separately.
 */
export class Store {
  constructor(home) {
    this.home = home;
    this.logFile = path.join(home, 'decisions.jsonl');
    this.lockDir = path.join(home, '.lock');
  }

  ensure() {
    fs.mkdirSync(this.home, { recursive: true });
  }

  withLock(fn) {
    this.ensure();
    const sleep = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
    const start = Date.now();
    for (;;) {
      try {
        fs.mkdirSync(this.lockDir);
        break;
      } catch (e) {
        if (e.code !== 'EEXIST') throw e;
        try {
          if (Date.now() - fs.statSync(this.lockDir).mtimeMs > 10000) fs.rmdirSync(this.lockDir);
        } catch {}
        if (Date.now() - start > 8000) throw new FlaireError('busy', 'Another Flaire process is busy. Try again.', 503);
        sleep(15);
      }
    }
    try {
      return fn();
    } finally {
      try {
        fs.rmdirSync(this.lockDir);
      } catch {}
    }
  }

  records() {
    if (!fs.existsSync(this.logFile)) return [];
    return fs
      .readFileSync(this.logFile, 'utf8')
      .split('\n')
      .filter(Boolean)
      .map((l) => JSON.parse(l));
  }

  append(rec, existing = this.records()) {
    const prev = existing.length ? existing[existing.length - 1].hash : 'GENESIS';
    const body = { ...rec, seq: existing.length + 1, prevHash: prev };
    const full = { ...body, hash: sha256(prev + canonical(body)) };
    fs.appendFileSync(this.logFile, JSON.stringify(full) + '\n');
    existing.push(full);
    return full;
  }
}

export function verifyChain(records) {
  let prev = 'GENESIS';
  for (let i = 0; i < records.length; i++) {
    const { hash, ...body } = records[i];
    if (body.prevHash !== prev || body.seq !== i + 1 || sha256(prev + canonical(body)) !== hash) {
      return { ok: false, count: records.length, brokenAt: i + 1 };
    }
    prev = hash;
  }
  return { ok: true, count: records.length, head: prev };
}

export function buildState(records) {
  const st = {
    agents: {},
    globalPaused: false,
    decisions: new Map(),
    settled: [],
    recent: [],
    usedReceipts: new Set(),
    head: records.length ? records[records.length - 1].hash : 'GENESIS'
  };
  const spend = (d, at) => {
    const a = st.agents[d.agent];
    if (a) a.balance -= d.amountHalalas;
    st.settled.push({ id: d.id, agent: d.agent, merchant: d.merchant, category: d.category, action: d.action, amount: d.amountHalalas, at });
  };
  for (const r of records) {
    const at = Date.parse(r.ts);
    switch (r.type) {
      case 'agent':
        st.agents[r.name] = { balance: r.fundHalalas, paused: false, createdAt: r.ts };
        break;
      case 'fund':
        if (st.agents[r.agent]) st.agents[r.agent].balance += r.amountHalalas;
        break;
      case 'decision': {
        const d = { ...r, status: r.verdict === 'allow' ? 'approved' : r.verdict === 'deny' ? 'denied' : 'pending', at };
        st.decisions.set(r.id, d);
        if (r.verdict !== 'deny') st.recent.push({ id: r.id, agent: r.agent, merchant: r.merchant, amountHalalas: r.amountHalalas, at });
        if (r.verdict === 'allow') spend(d, at);
        break;
      }
      case 'resolution': {
        const d = st.decisions.get(r.decisionId);
        if (!d) break;
        d.status = r.outcome;
        d.resolution = r;
        d.resolvedAt = at;
        if (r.outcome === 'approved') spend(d, at);
        break;
      }
      case 'control':
        if (r.scope === 'all') st.globalPaused = r.action === 'pause';
        else if (st.agents[r.scope]) st.agents[r.scope].paused = r.action === 'pause';
        break;
      case 'rail': {
        const d = st.decisions.get(r.decisionId);
        if (!d) break;
        d.rail = r;
        if (!r.ok && d.status === 'approved') {
          // The payment rail refused or failed, so the simulated spend never happened. Give the budget back.
          d.status = 'rail_failed';
          const a = st.agents[d.agent];
          if (a) a.balance += d.amountHalalas;
          st.settled = st.settled.filter((x) => x.id !== d.id);
        }
        break;
      }
      case 'receipt_use':
        st.usedReceipts.add(r.decisionId);
        break;
    }
  }
  return st;
}
