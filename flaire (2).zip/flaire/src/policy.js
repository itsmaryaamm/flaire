import fs from 'node:fs';
import { FlaireError, canonical, sha256, merchantMatches } from './util.js';
import { parseAmount } from './money.js';

export const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

// The owner edits this file (policy.json). It is read fresh on every request.
export const DEFAULT_POLICY = {
  name: 'Flaire default policy (SAR)',
  currency: 'SAR',
  defaultVerdict: 'review',
  reviewAbove: '250.00',
  limits: { perTransaction: '500.00', daily: '1000.00', monthly: '10000.00' },
  duplicateWindowSeconds: 120,
  pendingExpiryHours: 24,
  schedule: null,
  blockedMerchants: [],
  blockedCategories: ['gambling', 'adult'],
  rules: [
    { id: 'jarir', merchant: 'jarir.com', actions: ['purchase'], verdict: 'allow', maxAmount: '300.00' },
    { id: 'noon', merchant: 'noon.com', actions: ['purchase'], verdict: 'allow', maxAmount: '300.00' },
    { id: 'stc', merchant: 'stc.com.sa', actions: ['purchase', 'bill_payment'], verdict: 'allow', maxAmount: '400.00' },
    { id: 'careem', merchant: 'careem.com', actions: ['purchase'], verdict: 'allow', maxAmount: '150.00', maxDaily: '300.00' },
    { id: 'ai-tools', merchant: 'openai.com', actions: ['purchase', 'api_call'], verdict: 'allow', maxAmount: '400.00', maxDaily: '800.00' },
    { id: 'gov-fees', merchant: '*.gov.sa', verdict: 'review' }
  ]
};

// Example of a Saudi working-week schedule (Sunday to Thursday). Copy into policy.json to enable.
export const EXAMPLE_SCHEDULE = {
  timezone: 'Asia/Riyadh',
  days: ['sun', 'mon', 'tue', 'wed', 'thu'],
  from: '08:00',
  to: '18:00',
  outside: 'review'
};

const VERDICTS = ['allow', 'deny', 'review'];

export function compilePolicy(raw) {
  const errs = [];
  const amt = (v, path) => {
    if (v === undefined || v === null) return null;
    try {
      return parseAmount(v, { allowZero: true });
    } catch {
      errs.push(`${path}: invalid amount "${v}"`);
      return null;
    }
  };
  if (!raw || typeof raw !== 'object') throw new FlaireError('invalid_policy', 'Policy must be a JSON object.');
  if ((raw.currency ?? 'SAR') !== 'SAR') errs.push('currency: only SAR is supported');
  const defaultVerdict = raw.defaultVerdict ?? 'review';
  if (!['review', 'deny'].includes(defaultVerdict)) errs.push('defaultVerdict: must be "review" or "deny"');
  const limits = {
    perTransaction: amt(raw.limits?.perTransaction, 'limits.perTransaction'),
    daily: amt(raw.limits?.daily, 'limits.daily'),
    monthly: amt(raw.limits?.monthly, 'limits.monthly')
  };
  const dupSec = raw.duplicateWindowSeconds ?? 120;
  if (!Number.isInteger(dupSec) || dupSec < 0) errs.push('duplicateWindowSeconds: must be a whole number >= 0');
  const ttlH = raw.pendingExpiryHours ?? 24;
  if (typeof ttlH !== 'number' || ttlH <= 0) errs.push('pendingExpiryHours: must be > 0');

  let schedule = null;
  if (raw.schedule) {
    const s = raw.schedule;
    const hm = (v) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(v ?? '') ? Number(v.slice(0, 2)) * 60 + Number(v.slice(3)) : null);
    const from = hm(s.from);
    const to = hm(s.to);
    if (from === null || to === null) errs.push('schedule.from/to: use HH:MM');
    if (!Array.isArray(s.days) || !s.days.length || s.days.some((d) => !DAYS.includes(d))) errs.push('schedule.days: use sun..sat');
    try {
      new Intl.DateTimeFormat('en-US', { timeZone: s.timezone });
    } catch {
      errs.push('schedule.timezone: unknown timezone');
    }
    if (!['review', 'deny'].includes(s.outside ?? 'review')) errs.push('schedule.outside: "review" or "deny"');
    schedule = { timezone: s.timezone, days: s.days, from, to, outside: s.outside ?? 'review' };
  }

  const strList = (v, path) => {
    if (v === undefined) return [];
    if (!Array.isArray(v) || v.some((x) => typeof x !== 'string')) {
      errs.push(`${path}: must be a list of text values`);
      return [];
    }
    return v.map((x) => x.toLowerCase().trim());
  };

  const seen = new Set();
  const rules = (raw.rules ?? []).map((r, i) => {
    const p = `rules[${i}]`;
    if (!r.id || typeof r.id !== 'string') errs.push(`${p}.id: required`);
    if (seen.has(r.id)) errs.push(`${p}.id: duplicate "${r.id}"`);
    seen.add(r.id);
    if (!r.merchant && !r.category) errs.push(`${p}: needs "merchant" or "category"`);
    if (!VERDICTS.includes(r.verdict)) errs.push(`${p}.verdict: allow, deny or review`);
    return {
      id: r.id,
      merchant: r.merchant ? String(r.merchant).toLowerCase() : null,
      category: r.category ? String(r.category).toLowerCase() : null,
      actions: r.actions ? strList(r.actions, `${p}.actions`) : null,
      verdict: r.verdict,
      maxAmount: amt(r.maxAmount, `${p}.maxAmount`),
      maxDaily: amt(r.maxDaily, `${p}.maxDaily`)
    };
  });

  if (errs.length) {
    const e = new FlaireError('invalid_policy', 'Policy problems:\n  - ' + errs.join('\n  - '));
    e.problems = errs;
    throw e;
  }
  return {
    name: raw.name ?? 'policy',
    currency: 'SAR',
    defaultVerdict,
    reviewAbove: amt(raw.reviewAbove, 'reviewAbove'),
    limits,
    duplicateWindowMs: dupSec * 1000,
    pendingTtlMs: ttlH * 3600 * 1000,
    schedule,
    blockedMerchants: strList(raw.blockedMerchants, 'blockedMerchants'),
    blockedCategories: strList(raw.blockedCategories, 'blockedCategories'),
    rules
  };
}

export function policyHash(raw) {
  return sha256(canonical(raw)).slice(0, 16);
}

export function loadPolicyFile(file) {
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    throw new FlaireError('invalid_policy', `Cannot read policy file ${file}: ${e.message}`, 500);
  }
  return { raw, compiled: compilePolicy(raw), hash: policyHash(raw) };
}

export function ruleMatches(rule, x) {
  if (rule.merchant && !merchantMatches(rule.merchant, x.merchant)) return false;
  if (rule.category && rule.category !== x.category) return false;
  if (rule.actions && !rule.actions.includes(x.action)) return false;
  return true;
}
