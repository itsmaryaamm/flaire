import { FlaireError } from './util.js';

// All money is an integer number of halalas (1 SAR = 100 halalas). Never floats.
export const USD_SAR_PEG = 3.75; // SAR is pegged to USD

export function parseAmount(input, { allowZero = false } = {}) {
  const s = typeof input === 'number' ? String(input) : String(input ?? '').trim();
  if (!/^\d{1,10}(\.\d{1,2})?$/.test(s)) {
    throw new FlaireError('invalid_amount', `Invalid amount "${input}". Use a plain number with at most 2 decimals.`);
  }
  const [w, f = ''] = s.split('.');
  const minor = Number(w) * 100 + Number((f + '00').slice(0, 2));
  if (minor <= 0 && !allowZero) throw new FlaireError('invalid_amount', 'Amount must be greater than zero.');
  return minor;
}

export function toHalalas(minor, currency) {
  if (currency === 'SAR') return minor;
  if (currency === 'USD') return Math.round((minor * USD_SAR_PEG * 100) / 100);
  throw new FlaireError('invalid_request', `Unsupported currency "${currency}". Use SAR or USD.`);
}

export function plain(halalas) {
  const sign = halalas < 0 ? '-' : '';
  const a = Math.abs(halalas);
  return `${sign}${Math.trunc(a / 100)}.${String(a % 100).padStart(2, '0')}`;
}

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
export function fmt(halalas, lang = 'en') {
  const a = Math.abs(halalas);
  const whole = Math.trunc(a / 100).toLocaleString('en-US');
  const frac = String(a % 100).padStart(2, '0');
  const sign = halalas < 0 ? '-' : '';
  if (lang === 'ar') {
    const s = `${whole.replace(/,/g, '٬')}٫${frac}`.replace(/\d/g, (d) => AR_DIGITS[d]);
    return `${sign}${s} ر.س`;
  }
  return `${sign}SAR ${whole}.${frac}`;
}
