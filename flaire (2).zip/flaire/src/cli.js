#!/usr/bin/env node
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Flaire, defaultHome } from './service.js';
import { FlaireError } from './util.js';
import { printDecision, bold, dim, green, red, amber } from './output.js';
import { fmt } from './money.js';
import { compilePolicy } from './policy.js';
import { runMcpStdio } from './mcp.js';
import { startServer } from './server.js';
import { runDemo } from './demo.js';
import { railFromEnv, authorizeAndPay, resolveAndPay, addAgentOnRail, fundOnRail, pauseOnRail } from './rail.js';

const VERSION = '0.2.0';
const HELP = `
${bold('Flaire')} ${VERSION}  spend controls for AI agents. Simulated SAR only.
Flaire ${VERSION}  ضوابط الإنفاق لوكلاء الذكاء الاصطناعي. ريال تجريبي فقط.

  flaire demo [--lang ar]            Run the 10 step story. No setup needed.
  flaire init                        Create policy.json and a secret in the data folder
  flaire agent add <name> [--fund N] Add an agent with a simulated SAR balance
  flaire fund <agent> <amount>       Add simulated SAR
  flaire authorize --agent A --merchant M --amount N [--currency SAR|USD] [--action purchase] [--category C] [--purpose "..."] [--key K]
  flaire approve <id> | reject <id>  Owner decision on a held request
  flaire pause [agent] | resume [agent]   Kill switch (no name = all agents)
  flaire status                      Balances, pending approvals, log health
  flaire history [--since 24h] [--limit 20]
  flaire decision <id>               Full detail and rule trace
  flaire receipt verify <token> [--consume]
  flaire verify                      Check the log has not been tampered with
  flaire policy check                Validate policy.json
  flaire lithic check                Test the Lithic sandbox connection (see LITHIC.md)
  flaire demo --lithic               Same story, but charges fake cards held by Lithic
  flaire serve [--port 4747]         Local dashboard (Arabic and English)
  flaire mcp [--print-config]        MCP server for AI agents (stdio)

Options: --home <folder> (or FLAIRE_HOME), --lang ar|en, --json
Data folder default: ~/.flaire  (C:\Users\you\.flaire on Windows)
`;

function parse(argv) {
  const pos = [];
  const flags = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const eq = a.indexOf('=');
      if (eq > 0) flags[a.slice(2, eq)] = a.slice(eq + 1);
      else {
        const next = argv[i + 1];
        if (next !== undefined && !next.startsWith('--')) {
          flags[a.slice(2)] = next;
          i++;
        } else flags[a.slice(2)] = true;
      }
    } else pos.push(a);
  }
  return { pos, flags };
}

async function main() {
  const { pos, flags } = parse(process.argv.slice(2));
  const cmd = pos[0];
  const lang = flags.lang === 'ar' || process.env.FLAIRE_LANG === 'ar' ? 'ar' : 'en';
  const json = !!flags.json;
  const out = (o) => console.log(JSON.stringify(o, null, 2));

  if (!cmd || cmd === 'help' || flags.help) return console.log(HELP);
  if (cmd === 'version' || flags.version) return console.log(VERSION);
  if (cmd === 'demo') return runDemo({ lang, lithic: !!flags.lithic });

  const flaire = new Flaire(flags.home || defaultHome());
  const rail = railFromEnv(flaire); // null unless LITHIC_API_KEY is set

  switch (cmd) {
    case 'init': {
      const r = flaire.init();
      return console.log(r.created.length ? `Created:\n  ${r.created.join('\n  ')}\nEdit policy.json to set your rules.` : `Already set up in ${r.home}`);
    }
    case 'agent': {
      if (pos[1] === 'add') {
        const r = await addAgentOnRail(flaire, rail, pos[2], flags.fund ?? '0');
        return console.log(`Agent ${r.name} created with simulated balance SAR ${r.balance}`);
      }
      return console.log('Usage: flaire agent add <name> [--fund 2000]');
    }
    case 'fund': {
      const r = await fundOnRail(flaire, rail, pos[1], pos[2]);
      return console.log(`${r.agent} balance is now SAR ${r.balance}`);
    }
    case 'authorize': {
      const d = await authorizeAndPay(flaire, rail, {
        agent: flags.agent,
        merchant: flags.merchant,
        amount: flags.amount,
        currency: flags.currency,
        action: flags.action,
        category: flags.category,
        purpose: flags.purpose,
        idempotencyKey: flags.key
      });
      if (json) out(d);
      else printDecision(d, lang);
      process.exitCode = d.verdict === 'allow' ? 0 : d.verdict === 'review' ? 2 : 3; // scripts can branch on this
      return;
    }
    case 'approve':
    case 'reject': {
      const d = await resolveAndPay(flaire, rail, pos[1], cmd, 'owner (cli)');
      return json ? out(d) : printDecision(d, lang);
    }
    case 'pause':
    case 'resume': {
      const r = await pauseOnRail(flaire, rail, cmd, pos[1] ?? 'all', 'owner (cli)');
      return console.log(`${cmd === 'pause' ? amber('PAUSED') : green('RESUMED')}: ${r.scope === 'all' ? 'all agents' : r.scope}`);
    }
    case 'status': {
      const s = flaire.status();
      if (json) return out(s);
      console.log(dim(rail ? 'Payment rail: Lithic SANDBOX (fake card money)' : 'Payment rail: none (local simulated balance only)'));
      console.log(bold('Agents') + (s.globalPaused ? red('   ALL PAUSED') : ''));
      if (!s.agents.length) console.log(dim('  none yet. Try: flaire agent add ops-agent --fund 2000'));
      for (const a of s.agents) console.log(`  ${a.name.padEnd(18)} balance SAR ${a.balance}   24h spend SAR ${a.spent24h}${a.paused ? red('   PAUSED') : ''}`);
      console.log(`Pending approvals: ${s.pending ? amber(s.pending) : 0}`);
      console.log(s.chain.ok ? green(`Log intact (${s.chain.count} records)`) : red(`LOG TAMPERED at record ${s.chain.brokenAt}`));
      return;
    }
    case 'history': {
      let sinceMs = 0;
      if (flags.since) {
        const m = /^(\d+)(m|h|d)$/.exec(flags.since);
        if (!m) throw new FlaireError('invalid_request', '--since: use 30m, 24h or 7d');
        sinceMs = Date.now() - Number(m[1]) * { m: 60e3, h: 3600e3, d: 86400e3 }[m[2]];
      }
      const list = flaire.history({ sinceMs, limit: Number(flags.limit) || 20 });
      if (json) return out(list);
      if (!list.length) return console.log(dim('No decisions yet.'));
      list.forEach((d) => printDecision(d, lang));
      return;
    }
    case 'decision': {
      const d = flaire.getDecision(pos[1]);
      if (json) return out(d);
      printDecision(d, lang);
      console.log(bold('\nRule trace'));
      for (const t of d.trace) console.log(`  ${t.check.padEnd(17)} ${t.result}${t.code ? '  ' + t.code : ''}`);
      return console.log(dim(`\npolicy ${d.policy}   purpose: ${d.purpose ?? '-'}`));
    }
    case 'receipt': {
      if (pos[1] !== 'verify') return console.log('Usage: flaire receipt verify <token> [--consume]');
      const r = flaire.verifyReceipt(pos[2], { consume: !!flags.consume });
      if (json) out(r);
      else console.log(r.valid ? green(`VALID  ${r.claims.a} -> ${r.claims.m}  ${fmt(r.claims.amt, lang)}`) : red(`INVALID: ${r.reason}`));
      process.exitCode = r.valid ? 0 : 1;
      return;
    }
    case 'verify': {
      const r = flaire.verifyLedger();
      console.log(r.ok ? green(`OK: ${r.count} records, chain intact`) : red(`FAILED: chain broken at record ${r.brokenAt}`));
      process.exitCode = r.ok ? 0 : 1;
      return;
    }
    case 'policy': {
      try {
        const { raw } = flaire.policy();
        compilePolicy(raw);
        return console.log(green(`policy.json is valid (${raw.rules?.length ?? 0} rules)`));
      } catch (e) {
        console.log(red(e.message));
        process.exitCode = 1;
        return;
      }
    }
    case 'lithic': {
      if (pos[1] !== 'check') return console.log('Usage: flaire lithic check   (needs LITHIC_API_KEY, see LITHIC.md)');
      if (!rail) throw new FlaireError('rail_config', 'Set LITHIC_API_KEY first. See LITHIC.md.');
      const name = 'lithic-check';
      if (!flaire.status().agents.some((a) => a.name === name)) await addAgentOnRail(flaire, rail, name, '100');
      console.log('Asking Flaire, then charging a SAR 15 test purchase on a Lithic sandbox card...');
      const d = await authorizeAndPay(flaire, rail, { agent: name, merchant: 'jarir.com', amount: 15, idempotencyKey: 'check-' + Date.now() });
      printDecision(d, lang);
      console.log(d.rail?.ok ? green('Lithic sandbox is connected and working.') : red('Lithic did not accept the charge. Read the message above.'));
      process.exitCode = d.rail?.ok ? 0 : 1;
      return;
    }
    case 'serve': {
      const port = Number(flags.port) || 4747;
      flaire.init();
      await startServer(flaire, port, rail);
      console.log(`${bold('Flaire dashboard')}: http://localhost:${port}   (this computer only, Ctrl+C to stop)`);
      console.log(dim(`Data folder: ${flaire.home}`));
      return;
    }
    case 'mcp': {
      if (flags['print-config']) {
        const cli = fileURLToPath(import.meta.url);
        return out({ mcpServers: { flaire: { command: process.execPath, args: [cli, 'mcp'], env: { FLAIRE_HOME: path.resolve(flaire.home) } } } });
      }
      flaire.init();
      return runMcpStdio(flaire, rail);
    }
    default:
      console.log(`Unknown command "${cmd}".`);
      console.log(HELP);
      process.exitCode = 1;
  }
}

main().catch((e) => {
  if (e instanceof FlaireError) {
    console.error(red(`Error: ${e.message}`));
    process.exitCode = 1;
  } else {
    console.error(e);
    process.exitCode = 1;
  }
});
