import { ruleMatches } from './policy.js';

const DAY_MS = 24 * 3600 * 1000;
const DAY_KEYS = { Sun: 'sun', Mon: 'mon', Tue: 'tue', Wed: 'wed', Thu: 'thu', Fri: 'fri', Sat: 'sat' };

export function inSchedule(s, date) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: s.timezone,
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23'
  }).formatToParts(date);
  const get = (t) => parts.find((p) => p.type === t).value;
  const mins = Number(get('hour')) * 60 + Number(get('minute'));
  return s.days.includes(DAY_KEYS[get('weekday')]) && mins >= s.from && mins < s.to;
}

function spent(state, agent, sinceMs, filter) {
  let t = 0;
  for (const s of state.settled) if (s.agent === agent && s.at > sinceMs && (!filter || filter(s))) t += s.amount;
  return t;
}

/**
 * Pure decision function. Same inputs always give the same answer.
 * A deny always beats a review. Anything not explicitly allowed goes to a human (or is denied).
 * approving=true is used when the owner approves a held request: hard checks run again
 * (pause, limits, balance) but "needs a human" triggers are already satisfied.
 */
export function evaluate(policy, state, req, opts = {}) {
  const now = (opts.now ?? new Date()).getTime();
  const approving = !!opts.approving;
  const trace = [];
  const review = [];
  const add = (check, result, code, params) => trace.push({ check, result, ...(code && { code }), ...(params && { params }) });
  const deny = (check, code, params) => {
    add(check, 'deny', code, params);
    return { verdict: 'deny', reasons: [{ code, ...(params && { params }) }], trace };
  };
  const flag = (check, code, params) => {
    if (approving) return add(check, 'pass', 'OWNER_APPROVED');
    add(check, 'review', code, params);
    review.push({ code, ...(params && { params }) });
  };

  const agent = state.agents[req.agent];
  if (!agent) return deny('agent', 'UNKNOWN_AGENT');
  add('agent', 'pass');

  if (state.globalPaused) return deny('kill_switch', 'KILL_SWITCH_ALL');
  if (agent.paused) return deny('kill_switch', 'KILL_SWITCH_AGENT');
  add('kill_switch', 'pass');

  if (!approving && policy.duplicateWindowMs > 0) {
    const dup = state.recent.find(
      (d) =>
        d.agent === req.agent &&
        d.merchant === req.merchant &&
        d.amountHalalas === req.amountHalalas &&
        now - d.at < policy.duplicateWindowMs
    );
    if (dup) return deny('duplicate', 'DUPLICATE_REQUEST', { of: dup.id });
  }
  add('duplicate', 'pass');

  if (policy.blockedMerchants.some((p) => ruleMatches({ merchant: p }, req))) return deny('blocklist', 'BLOCKED_MERCHANT');
  if (req.category && policy.blockedCategories.includes(req.category)) return deny('blocklist', 'BLOCKED_CATEGORY');
  add('blocklist', 'pass');

  const L = policy.limits;
  if (L.perTransaction != null && req.amountHalalas > L.perTransaction) return deny('per_transaction', 'OVER_TX_CAP', { limit: L.perTransaction });
  add('per_transaction', 'pass');
  if (L.daily != null) {
    const used = spent(state, req.agent, now - DAY_MS);
    if (used + req.amountHalalas > L.daily) return deny('daily', 'OVER_DAILY', { limit: L.daily, used });
  }
  add('daily', 'pass');
  if (L.monthly != null) {
    const used = spent(state, req.agent, now - 30 * DAY_MS);
    if (used + req.amountHalalas > L.monthly) return deny('monthly', 'OVER_MONTHLY', { limit: L.monthly, used });
  }
  add('monthly', 'pass');

  const rule = policy.rules.find((r) => ruleMatches(r, req));
  if (!rule) {
    if (policy.defaultVerdict === 'deny') return deny('rule', 'NO_RULE_MATCH_DENIED');
    flag('rule', 'NO_RULE_MATCH');
  } else {
    if (rule.verdict === 'deny') return deny('rule', 'RULE_DENY', { rule: rule.id });
    if (rule.maxAmount != null && req.amountHalalas > rule.maxAmount) return deny('rule', 'OVER_RULE_MAX', { rule: rule.id, limit: rule.maxAmount });
    if (rule.maxDaily != null) {
      const used = spent(state, req.agent, now - DAY_MS, (s) => ruleMatches(rule, s));
      if (used + req.amountHalalas > rule.maxDaily) return deny('rule', 'OVER_RULE_DAILY', { rule: rule.id, limit: rule.maxDaily, used });
    }
    if (rule.verdict === 'review') flag('rule', 'RULE_REVIEW', { rule: rule.id });
    else add('rule', 'pass', undefined, { rule: rule.id });
  }

  if (req.amountHalalas > agent.balance) return deny('balance', 'INSUFFICIENT_FUNDS', { balance: agent.balance });
  add('balance', 'pass');

  if (policy.reviewAbove != null && req.amountHalalas > policy.reviewAbove) flag('review_threshold', 'OVER_REVIEW_THRESHOLD', { limit: policy.reviewAbove });
  else add('review_threshold', 'pass');

  if (policy.schedule && !approving) {
    if (!inSchedule(policy.schedule, new Date(now))) {
      if (policy.schedule.outside === 'deny') return deny('schedule', 'OUTSIDE_HOURS');
      flag('schedule', 'OUTSIDE_HOURS');
    } else add('schedule', 'pass');
  }

  if (review.length) return { verdict: 'review', reasons: review, trace };
  return { verdict: 'allow', reasons: [{ code: 'WITHIN_POLICY' }], trace };
}
