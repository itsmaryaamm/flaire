import http from 'node:http';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { FlaireError } from './util.js';

const INDEX = fileURLToPath(new URL('../web/index.html', import.meta.url));

// Local dashboard. Binds to 127.0.0.1 only. The owner actions (approve, pause) are protected from
// other websites by requiring a custom header (forces a CORS preflight we never answer) and a Host check.
import { authorizeAndPay, resolveAndPay, addAgentOnRail, fundOnRail, pauseOnRail } from './rail.js';

export function startServer(flaire, port = 4747, rail = null) {
  const hostOk = (h) => h === `127.0.0.1:${port}` || h === `localhost:${port}`;
  const server = http.createServer((req, res) => {
    const send = (code, body, type = 'application/json; charset=utf-8') => {
      res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
      res.end(typeof body === 'string' ? body : JSON.stringify(body));
    };
    if (!hostOk(req.headers.host)) return send(403, { error: 'bad_host' });
    const url = new URL(req.url, 'http://x');

    if (req.method === 'GET' && url.pathname === '/') return send(200, fs.readFileSync(INDEX, 'utf8'), 'text/html; charset=utf-8');
    if (req.method === 'GET' && url.pathname === '/api/state') {
      return send(200, { rail: rail ? 'lithic' : 'local', status: flaire.status(), pending: flaire.pending(), history: flaire.history({ limit: 40 }) });
    }
    if (req.method !== 'POST' || !url.pathname.startsWith('/api/')) return send(404, { error: 'not_found' });
    if (req.headers['x-flaire'] !== '1') return send(403, { error: 'missing_header' });

    let raw = '';
    req.on('data', (c) => {
      raw += c;
      if (raw.length > 65536) req.destroy();
    });
    req.on('end', async () => {
      try {
        const b = raw ? JSON.parse(raw) : {};
        switch (url.pathname) {
          case '/api/authorize':
            return send(200, await authorizeAndPay(flaire, rail, b));
          case '/api/resolve':
            return send(200, await resolveAndPay(flaire, rail, b.id, b.choice, 'owner (dashboard)'));
          case '/api/pause':
            return send(200, await pauseOnRail(flaire, rail, b.resume ? 'resume' : 'pause', b.scope ?? 'all', 'owner (dashboard)'));
          case '/api/fund':
            return send(200, await fundOnRail(flaire, rail, b.agent, b.amount));
          case '/api/agent':
            return send(200, await addAgentOnRail(flaire, rail, b.name, b.fund ?? '0'));
          default:
            return send(404, { error: 'not_found' });
        }
      } catch (e) {
        if (e instanceof FlaireError) return send(e.status, { error: { code: e.code, message: e.message } });
        if (e instanceof SyntaxError) return send(400, { error: { code: 'bad_json', message: 'Invalid JSON' } });
        process.stderr.write(e.stack + '\n');
        return send(500, { error: { code: 'internal', message: 'Internal error' } });
      }
    });
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', () => resolve(server));
  });
}
