import fs from 'node:fs';
import path from 'node:path';
import { FlaireError } from './util.js';
import { USD_SAR_PEG } from './money.js';

// Lithic holds the (fake) card money in its SANDBOX. Flaire decides, and only a valid Flaire receipt
// can trigger a charge. Flaire refuses to talk to anything except the Lithic sandbox.
const ALLOWED_HOSTS = ['sandbox.lithic.com', '127.0.0.1', 'localhost'];

export const halalasToUsdCents = (h) => Math.round(h / USD_SAR_PEG); // 3.75 halalas per US cent

export class LithicRail {
  constructor(flaire, { apiKey, baseUrl, fetchImpl, retryScale = 1 } = {}) {
    if (!apiKey) throw new FlaireError('rail_config', 'LITHIC_API_KEY is not set.');
    const base = baseUrl || 'https://sandbox.lithic.com/v1';
    let u;
    try {
      u = new URL(base);
    } catch {
      throw new FlaireError('rail_config', `Bad LITHIC_BASE_URL: ${base}`);
    }
    if (!ALLOWED_HOSTS.includes(u.hostname)) throw new FlaireError('rail_config', 'Flaire only connects to the Lithic SANDBOX (sandbox.lithic.com), never production.');
    this.flaire = flaire;
    this.retryScale = retryScale; // tests set 0 so they do not wait
    this.apiKey = apiKey;
    this.base = base.replace(/\/$/, '');
    this.fetch = fetchImpl || globalThis.fetch;
    this.cardsFile = path.join(flaire.home, 'lithic-cards.json');
  }

  cards() {
    try {
      return JSON.parse(fs.readFileSync(this.cardsFile, 'utf8'));
    } catch {
      return {};
    }
  }
  saveCards(c) {
    fs.mkdirSync(this.flaire.home, { recursive: true });
    fs.writeFileSync(this.cardsFile, JSON.stringify(c, null, 2), { mode: 0o600 }); // sandbox test card numbers only
  }

  async call(method, pathname, body, attempt = 0) {
    let res;
    try {
      res = await this.fetch(this.base + pathname, {
        method,
        headers: { Authorization: this.apiKey, 'Content-Type': 'application/json', Accept: 'application/json' },
        body: body ? JSON.stringify(body) : undefined
      });
    } catch (e) {
      throw new FlaireError('rail_unreachable', `Could not reach Lithic: ${e.message}`, 502);
    }
    // Lithic says "too many requests": wait as long as it asks (up to 30s) and try again, up to 3 times.
    // Safe to repeat, because a rate-limited request was refused before it did anything.
    if (res.status === 429 && attempt < 3) {
      const ra = Number(res.headers?.get?.('retry-after'));
      const wait = Math.min(Math.max(Number.isFinite(ra) ? ra : 5, 0), 30);
      await new Promise((r) => setTimeout(r, wait * 1000 * this.retryScale));
      return this.call(method, pathname, body, attempt + 1);
    }
    let json = null;
    try {
      json = await res.json();
    } catch {}
    if (!res.ok) throw new FlaireError('rail_error', `Lithic said no: ${json?.message || json?.error?.message || 'HTTP ' + res.status}`, 502);
    return json;
  }

  async ensureCard(agent) {
    const cards = this.cards();
    if (cards[agent]) return cards[agent];
    const limit = halalasToUsdCents(this.flaire.totalFunded(agent));
    const r = await this.call('POST', '/cards', { type: 'VIRTUAL', memo: `flaire:${agent}`, spend_limit: limit, spend_limit_duration: 'FOREVER', state: 'OPEN' });
    if (!r?.token || !r?.pan) throw new FlaireError('rail_error', 'Lithic did not return a card token and test card number.', 502);
    cards[agent] = { token: r.token, pan: r.pan, last_four: r.last_four };
    this.saveCards(cards);
    return cards[agent];
  }

  async syncLimit(agent) {
    const card = await this.ensureCard(agent);
    await this.call('PATCH', `/cards/${card.token}`, { spend_limit: halalasToUsdCents(this.flaire.totalFunded(agent)) });
  }

  async setPaused(scope, paused) {
    const cards = this.cards();
    const names = scope === 'all' ? Object.keys(cards) : cards[scope] ? [scope] : [];
    for (const n of names) await this.call('PATCH', `/cards/${cards[n].token}`, { state: paused ? 'PAUSED' : 'OPEN' });
    return names;
  }

  // Present a Flaire receipt. It is checked and used up first, so it can only ever cause one charge.
  async pay(decisionId, receipt) {
    const v = this.flaire.verifyReceipt(receipt, { consume: true });
    if (!v.valid) {
      this.flaire.recordRail(decisionId, { rail: 'lithic', ok: false, error: `Receipt refused: ${v.reason}` });
      return { ok: false, error: `Receipt refused: ${v.reason}` };
    }
    const c = v.claims;
    const usdCents = halalasToUsdCents(c.amt);
    try {
      if (usdCents < 1) throw new FlaireError('rail_error', 'Amount is below one US cent, the smallest Lithic charge.');
      const card = await this.ensureCard(c.a);
      const auth = await this.call('POST', '/simulate/authorize', { amount: usdCents, descriptor: c.m.toUpperCase().slice(0, 25), pan: card.pan });
      await this.call('POST', '/simulate/clearing', { token: auth.token, amount: usdCents });
      this.flaire.recordRail(decisionId, { rail: 'lithic', ok: true, authToken: auth.token, usdCents });
      return { ok: true, authToken: auth.token, usdCents };
    } catch (e) {
      if (!(e instanceof FlaireError)) throw e;
      this.flaire.recordRail(decisionId, { rail: 'lithic', ok: false, error: e.message });
      return { ok: false, error: e.message };
    }
  }
}

export function railFromEnv(flaire) {
  if (!process.env.LITHIC_API_KEY) return null;
  return new LithicRail(flaire, { apiKey: process.env.LITHIC_API_KEY, baseUrl: process.env.LITHIC_BASE_URL });
}

// ---- helpers used by the CLI, dashboard and MCP so every path behaves the same ----
async function settle(flaire, rail, d) {
  if (!rail || d.status !== 'approved' || !d.receipt) return d;
  await rail.pay(d.id, d.receipt);
  return flaire.getDecision(d.id);
}
export async function authorizeAndPay(flaire, rail, input) {
  return settle(flaire, rail, flaire.authorize(input));
}
export async function resolveAndPay(flaire, rail, id, choice, by) {
  return settle(flaire, rail, flaire.resolve(id, choice, by));
}
export async function addAgentOnRail(flaire, rail, name, fund) {
  const r = flaire.addAgent(name, fund);
  if (rail) await rail.ensureCard(name);
  return r;
}
export async function fundOnRail(flaire, rail, agent, amount) {
  const r = flaire.fund(agent, amount);
  if (rail) await rail.syncLimit(agent);
  return r;
}
export async function pauseOnRail(flaire, rail, action, scope, by) {
  const r = action === 'pause' ? flaire.pause(scope, by) : flaire.resume(scope, by);
  if (rail) await rail.setPaused(scope, action === 'pause'); // the card itself is paused at Lithic too
  return r;
}
