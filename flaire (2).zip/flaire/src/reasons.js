import { fmt } from './money.js';

// Every decision carries stable reason codes plus a human message in English and Arabic.
const M = {
  WITHIN_POLICY: () => ({ en: 'Within policy', ar: 'ضمن السياسة' }),
  APPROVED_BY_OWNER: () => ({ en: 'Approved by the owner', ar: 'وافق عليها المالك' }),
  REJECTED_BY_OWNER: () => ({ en: 'Rejected by the owner', ar: 'رفضها المالك' }),
  PENDING_EXPIRED: () => ({ en: 'Review window expired', ar: 'انتهت مهلة المراجعة' }),
  UNKNOWN_AGENT: () => ({ en: 'Unknown agent', ar: 'وكيل غير معروف' }),
  KILL_SWITCH_AGENT: () => ({ en: 'This agent is paused by the owner', ar: 'تم إيقاف هذا الوكيل من قبل المالك' }),
  KILL_SWITCH_ALL: () => ({ en: 'All agents are paused by the owner', ar: 'تم إيقاف جميع الوكلاء من قبل المالك' }),
  DUPLICATE_REQUEST: () => ({ en: 'Duplicate of a recent request', ar: 'طلب مكرر لطلب سابق حديث' }),
  BLOCKED_MERCHANT: () => ({ en: 'Merchant is blocked', ar: 'التاجر محظور' }),
  BLOCKED_CATEGORY: () => ({ en: 'Category is blocked', ar: 'الفئة محظورة' }),
  RULE_DENY: (p) => ({ en: `Rule "${p.rule}" denies this`, ar: `القاعدة "${p.rule}" تمنع هذا الطلب` }),
  RULE_REVIEW: (p) => ({ en: `Rule "${p.rule}" needs owner review`, ar: `القاعدة "${p.rule}" تتطلب مراجعة المالك` }),
  NO_RULE_MATCH: () => ({ en: 'No rule covers this merchant, owner review needed', ar: 'لا توجد قاعدة لهذا التاجر، يلزم مراجعة المالك' }),
  NO_RULE_MATCH_DENIED: () => ({ en: 'No rule covers this merchant, denied by default', ar: 'لا توجد قاعدة لهذا التاجر، مرفوض افتراضيا' }),
  OVER_TX_CAP: (p) => ({
    en: `Above the per-transaction limit of ${fmt(p.limit)}`,
    ar: `يتجاوز حد العملية الواحدة وهو ${fmt(p.limit, 'ar')}`
  }),
  OVER_RULE_MAX: (p) => ({
    en: `Above the ${fmt(p.limit)} limit for this merchant`,
    ar: `يتجاوز حد هذا التاجر وهو ${fmt(p.limit, 'ar')}`
  }),
  OVER_DAILY: (p) => ({
    en: `Would pass the daily limit of ${fmt(p.limit)} (already spent ${fmt(p.used)})`,
    ar: `سيتجاوز الحد اليومي وهو ${fmt(p.limit, 'ar')} (المصروف ${fmt(p.used, 'ar')})`
  }),
  OVER_RULE_DAILY: (p) => ({
    en: `Would pass the merchant daily limit of ${fmt(p.limit)} (already spent ${fmt(p.used)})`,
    ar: `سيتجاوز الحد اليومي لهذا التاجر وهو ${fmt(p.limit, 'ar')} (المصروف ${fmt(p.used, 'ar')})`
  }),
  OVER_MONTHLY: (p) => ({
    en: `Would pass the 30-day limit of ${fmt(p.limit)} (already spent ${fmt(p.used)})`,
    ar: `سيتجاوز حد الثلاثين يوما وهو ${fmt(p.limit, 'ar')} (المصروف ${fmt(p.used, 'ar')})`
  }),
  INSUFFICIENT_FUNDS: (p) => ({
    en: `Simulated balance too low (${fmt(p.balance)})`,
    ar: `الرصيد التجريبي غير كاف (${fmt(p.balance, 'ar')})`
  }),
  OVER_REVIEW_THRESHOLD: (p) => ({
    en: `Above ${fmt(p.limit)}, the owner must approve`,
    ar: `يتجاوز ${fmt(p.limit, 'ar')}، يلزم موافقة المالك`
  }),
  OUTSIDE_HOURS: () => ({ en: 'Outside allowed working hours', ar: 'خارج ساعات العمل المسموحة' })
};

export function describe(reason) {
  const f = M[reason.code];
  return { code: reason.code, message: f ? f(reason.params ?? {}) : { en: reason.code, ar: reason.code }, params: reason.params };
}
