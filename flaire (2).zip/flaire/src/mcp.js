import readline from 'node:readline';
import { FlaireError } from './util.js';
import { authorizeAndPay } from './rail.js';

// Minimal MCP server over stdio (newline-delimited JSON-RPC). No dependencies.
// Agents get ask-only tools. Approving, rejecting and the kill switch are owner-only (CLI or dashboard).
const TOOLS = [
  {
    name: 'authorize_action',
    description:
      'Ask Flaire whether a spend is allowed BEFORE paying. Returns verdict allow, deny or review with reasons. Only proceed on allow, and present the receipt to the payment step. On review, wait for the owner. Never retry a denied request with different wording to get around a limit.',
    inputSchema: {
      type: 'object',
      properties: {
        agent: { type: 'string', description: 'Your agent name' },
        merchant: { type: 'string', description: 'Merchant domain or name, e.g. jarir.com' },
        amount: { type: ['number', 'string'], description: 'Amount, up to 2 decimals' },
        currency: { type: 'string', enum: ['SAR', 'USD'], description: 'Default SAR' },
        action: { type: 'string', description: 'purchase, api_call, bill_payment ... default purchase' },
        category: { type: 'string' },
        purpose: { type: 'string', description: 'Why you are spending this, in plain words' },
        idempotency_key: { type: 'string', description: 'Reuse the same key when retrying the same request' }
      },
      required: ['agent', 'merchant', 'amount']
    }
  },
  {
    name: 'get_decision',
    description: 'Look up a past decision by id.',
    inputSchema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] }
  },
  {
    name: 'get_pending_approvals',
    description: 'List requests waiting for the owner.',
    inputSchema: { type: 'object', properties: { agent: { type: 'string' } } }
  },
  {
    name: 'get_balance',
    description: 'Simulated SAR balance for an agent.',
    inputSchema: { type: 'object', properties: { agent: { type: 'string' } }, required: ['agent'] }
  }
];

async function callTool(flaire, rail, name, a = {}) {
  switch (name) {
    case 'authorize_action': {
      const { trace, ...d } = await authorizeAndPay(flaire, rail, { ...a, idempotencyKey: a.idempotency_key });
      return d;
    }
    case 'get_decision': {
      const { trace, ...d } = flaire.getDecision(a.id);
      return d;
    }
    case 'get_pending_approvals':
      return flaire.pending(a.agent).map(({ trace, ...d }) => d);
    case 'get_balance':
      return flaire.balance(a.agent);
    default:
      throw new FlaireError('unknown_tool', `Unknown tool ${name}`);
  }
}

export function createMcpHandler(flaire, rail = null) {
  return async function handle(msg) {
    const { id, method, params } = msg;
    const reply = (result) => ({ jsonrpc: '2.0', id, result });
    const error = (code, message) => ({ jsonrpc: '2.0', id, error: { code, message } });
    if (id === undefined) return null; // notifications get no reply
    switch (method) {
      case 'initialize':
        return reply({
          protocolVersion: params?.protocolVersion ?? '2024-11-05',
          capabilities: { tools: {} },
          serverInfo: { name: 'flaire', version: '0.2.0' }
        });
      case 'ping':
        return reply({});
      case 'tools/list':
        return reply({ tools: TOOLS });
      case 'tools/call':
        try {
          const out = await callTool(flaire, rail, params?.name, params?.arguments);
          return reply({ content: [{ type: 'text', text: JSON.stringify(out, null, 2) }] });
        } catch (e) {
          if (!(e instanceof FlaireError)) throw e;
          return reply({ isError: true, content: [{ type: 'text', text: JSON.stringify({ error: e.code, message: e.message }) }] });
        }
      default:
        return error(-32601, `Method not found: ${method}`);
    }
  };
}

export function runMcpStdio(flaire, rail = null) {
  const handle = createMcpHandler(flaire, rail);
  const rl = readline.createInterface({ input: process.stdin });
  rl.on('line', async (line) => {
    if (!line.trim()) return;
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }) + '\n');
      return;
    }
    try {
      const out = await handle(msg);
      if (out) process.stdout.write(JSON.stringify(out) + '\n');
    } catch (e) {
      process.stderr.write(`flaire mcp error: ${e.stack}\n`);
      if (msg.id !== undefined) process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: msg.id, error: { code: -32603, message: 'Internal error' } }) + '\n');
    }
  });
}
