// Put Flaire in front of ANY Node agent's spending. Needs Flaire installed globally (see README).
// Usage: import { guard } from './guard.js';  const ok = await guard('my-agent', 'jarir.com', 120);
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export function guard(agent, merchant, amount, { currency = 'SAR', purpose = '' } = {}) {
  const args = ['authorize', '--agent', agent, '--merchant', merchant, '--amount', String(amount), '--currency', currency, '--json'];
  if (purpose) args.push('--purpose', purpose);
  let out;
  try {
    out = execFileSync('flaire', args, { encoding: 'utf8', shell: process.platform === 'win32' });
  } catch (e) {
    out = e.stdout; // exit code 2 (review) or 3 (deny) still prints the decision
    if (!out) throw e;
  }
  const d = JSON.parse(out);
  return { allowed: d.verdict === 'allow', verdict: d.verdict, reasons: d.reasons.map((r) => r.message.en), decision: d };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  console.log(guard('demo-agent', 'jarir.com', 50)); // run: node examples/guard.js
}
