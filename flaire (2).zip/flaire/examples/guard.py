"""Put Flaire in front of ANY Python agent's spending. Needs Flaire installed globally (see README).
Usage:  from guard import guard;  r = guard("my-agent", "jarir.com", 120)
"""
import json
import shutil
import subprocess


def guard(agent, merchant, amount, currency="SAR", purpose=""):
    exe = shutil.which("flaire") or "flaire"
    cmd = [exe, "authorize", "--agent", agent, "--merchant", merchant,
           "--amount", str(amount), "--currency", currency, "--json"]
    if purpose:
        cmd += ["--purpose", purpose]
    p = subprocess.run(cmd, capture_output=True, text=True)  # exit 0 allow, 2 review, 3 deny
    if not p.stdout.strip():
        raise RuntimeError(p.stderr.strip() or "Flaire returned nothing")
    d = json.loads(p.stdout)
    return {"allowed": d["verdict"] == "allow", "verdict": d["verdict"],
            "reasons": [r["message"]["en"] for r in d["reasons"]], "decision": d}


if __name__ == "__main__":
    print(guard("demo-agent", "jarir.com", 50))
