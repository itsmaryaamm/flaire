// Usage: node scripts/set-github-user.js your-github-username
// Replaces the YOUR-USERNAME placeholder in the README and package.json.
import fs from 'node:fs';
const user = process.argv[2];
if (!user || !/^[A-Za-z0-9-]{1,39}$/.test(user)) {
  console.error('Usage: node scripts/set-github-user.js your-github-username');
  process.exit(1);
}
for (const f of ['README.md', 'package.json', 'LITHIC.md']) {
  fs.writeFileSync(f, fs.readFileSync(f, 'utf8').replaceAll('YOUR-USERNAME', user));
}
console.log(`Done. Repo links now point to github.com/${user}/flaire`);
